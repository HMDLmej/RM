---------------------------------------------------------------------------------------------------------------------------------------
**[CAM DUMPER]**
---------------------------------------------------------------------------------------------------------------------------------------

Cam-dumper is a written tool in the language of Python program for hacking CCTV cameras that can access cameras in 20 countries

---------------------------------------------------------------------------------------------------------------------------------------
instagram: @n.erfvn / telegram: @radar_db
---------------------------------------------------------------------------------------------------------------------------------------

**INSTALL WINDOWS**

1. install python 3.9.5
2. run cmd
3. pip install requests
4. pip install colorama
5. python Cam Dumper.py


---------------------------------------------------------------------------------------------------------------------------------------

**INSTALL LINUX**

1. apt-get install python3
2. apt-get install git
3. git clone https://github.com/erfannoori/Cam-Dumper.git
4. pip/pip3 install -r requirements.txt
5. pip install colorama
6. python3 Cam Dumper.py

---------------------------------------------------------------------------------------------------------------------------------------
![cam-dumper](https://github.com/erfannoori/Cam-Dumper/assets/77107767/36aaaa40-df65-4c54-a6ee-e125a3f5ffab)



